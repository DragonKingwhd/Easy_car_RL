import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import AssetBaseCfg
from isaaclab.assets.articulation import ArticulationCfg
from isaaclab.scene import InteractiveScene, InteractiveSceneCfg
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
CAR_CONFIG = ArticulationCfg(
    spawn=sim_utils.UsdFileCfg(
        usd_path=f"/home/a/car/car.usd",
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            enabled_self_collisions=False, solver_position_iteration_count=8, solver_velocity_iteration_count=4
        ),
    ),
    init_state=ArticulationCfg.InitialStateCfg(
        joint_pos={
            "joint_wheel_right": 0.0,
            "joint_wheel_left": 0.0,
            "joint_swing_left": 0.0,
            "joint_swing_right": 0.0,
        },
        pos=(0, 0, 0),
    ),
    actuators={
        "front": ImplicitActuatorCfg(
            joint_names_expr=["joint_wheel_right","joint_wheel_left"],
            effort_limit_sim=100.0,
            velocity_limit_sim=100.0,
            stiffness=10.0,
            damping=100.0,
        ),
        "back": ImplicitActuatorCfg(
            joint_names_expr=["joint_swing_left","joint_swing_right"],
            effort_limit_sim=100.0,
            velocity_limit_sim=100.0,
            stiffness=10.0,
            damping=100.0,
        ),
    },
)