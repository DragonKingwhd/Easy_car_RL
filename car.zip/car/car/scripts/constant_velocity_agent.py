# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Script that drives the Car robot with constant wheel velocities."""

import argparse

from isaaclab.app import AppLauncher

# add argparse arguments
parser = argparse.ArgumentParser(description="Constant velocity agent for Car Isaac Lab environments.")
parser.add_argument(
    "--front-speed",
    type=float,
    default=20.0,
    help="Target angular velocity for front wheel joints (both wheels use same speed).",
)
parser.add_argument(
    "--front-speeds",
    type=float,
    nargs="*",
    default=None,
    help="Explicit angular velocity per front wheel joint (expects two values: right, left). Overrides --front-speed if supplied.",
)
parser.add_argument(
    "--back-speed",
    type=float,
    default=0.0,
    help="Target angular velocity for back swing joints (both joints use same speed).",
)
parser.add_argument(
    "--back-speeds",
    type=float,
    nargs="*",
    default=None,
    help="Explicit angular velocity per back swing joint (expects two values: left, right). Overrides --back-speed if supplied.",
)
parser.add_argument("--num_envs", type=int, default=None, help="Number of environments to simulate.")
parser.add_argument("--task", type=str, default=None, help="Name of the task.")
parser.add_argument(
    "--disable_fabric",
    action="store_true",
    default=False,
    help="Disable fabric and use USD I/O operations.",
)
# append AppLauncher args
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

# launch omniverse app
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

"""Rest everything follows."""

import gymnasium as gym
import torch

import isaaclab_tasks  # noqa: F401
from isaaclab_tasks.utils import parse_env_cfg

import car.tasks  # noqa: F401

# Define joint ordering that matches the action manager configuration.
# ActionsCfg controls: front wheels (2) + back swing joints (2) = 4 total
FRONT_JOINTS = [
    "joint_wheel_right",
    "joint_wheel_left",
]

BACK_JOINTS = [
    "joint_swing_left",
    "joint_swing_right",
]


def main():
    """Drives the Car robot with fixed front and back joint velocity commands."""
    # create environment configuration
    env_cfg = parse_env_cfg(
        args_cli.task, device=args_cli.device, num_envs=args_cli.num_envs, use_fabric=not args_cli.disable_fabric
    )
    # create environment
    env = gym.make(args_cli.task, cfg=env_cfg)

    # resolve action dimensions
    num_envs = env.unwrapped.num_envs
    action_dim = env.action_space.shape[-1]
    device = env.unwrapped.device

    # Expected action dimension: 2 front joints + 2 back joints = 4
    expected_dim = len(FRONT_JOINTS) + len(BACK_JOINTS)
    if expected_dim != action_dim:
        raise RuntimeError(
            f"Unexpected action dimension. Expected {expected_dim}, got {action_dim}. "
            "Please verify the ActionsCfg configuration."
        )

    # prepare constant command
    actions = torch.zeros((num_envs, action_dim), device=device)

    # Handle front wheel speeds
    if args_cli.front_speeds is not None:
        if len(args_cli.front_speeds) != len(FRONT_JOINTS):
            parser.error(f"--front-speeds expects {len(FRONT_JOINTS)} values.")
        front_cmd = torch.tensor(args_cli.front_speeds, device=device, dtype=actions.dtype)
    else:
        front_cmd = torch.full(
            (len(FRONT_JOINTS),), args_cli.front_speed, device=device, dtype=actions.dtype
        )

    # Handle back swing speeds
    if args_cli.back_speeds is not None:
        if len(args_cli.back_speeds) != len(BACK_JOINTS):
            parser.error(f"--back-speeds expects {len(BACK_JOINTS)} values.")
        back_cmd = torch.tensor(args_cli.back_speeds, device=device, dtype=actions.dtype)
    else:
        back_cmd = torch.full(
            (len(BACK_JOINTS),), args_cli.back_speed, device=device, dtype=actions.dtype
        )

    # Assign commands to actions: front joints first, then back joints
    actions[:, : len(FRONT_JOINTS)] = front_cmd
    actions[:, len(FRONT_JOINTS) : len(FRONT_JOINTS) + len(BACK_JOINTS)] = back_cmd

    # print info
    print(f"[INFO]: Gym observation space: {env.observation_space}")
    print(f"[INFO]: Gym action space: {env.action_space}")
    print(f"[INFO]: Number of environments: {num_envs}")
    print(f"[INFO]: Front wheel command (right, left): {front_cmd.cpu().numpy().tolist()}")
    print(f"[INFO]: Back swing command (left, right): {back_cmd.cpu().numpy().tolist()}")

    # reset environment
    env.reset()

    # simulate environment
    while simulation_app.is_running():
        with torch.inference_mode():
            env.step(actions)

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
